package bean;

public class CourseBean {
	
	private int cid=0;
	private String cname="";
	private float ccredit=0.0f;
	private String cteacher="";
	private String cdepartment="";
	private int cmaxnums=0;
	private int ccurnums=0;
	
	public int getCid() {
		return cid;
	}
	public void setCid(int cid) {
		this.cid = cid;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public float getCcredit() {
		return ccredit;
	}
	public void setCcredit(float ccredit) {
		this.ccredit = ccredit;
	}
	public String getCteacher() {
		return cteacher;
	}
	public void setCteacher(String cteacher) {
		this.cteacher = cteacher;
	}
	public String getCdepartment() {
		return cdepartment;
	}
	public void setCdepartment(String cdepartment) {
		this.cdepartment = cdepartment;
	}
	public int getCmaxnums() {
		return cmaxnums;
	}
	public void setCmaxnums(int cmaxnums) {
		this.cmaxnums = cmaxnums;
	}
	public int getCcurnums() {
		return ccurnums;
	}
	public void setCcurnums(int ccurnums) {
		this.ccurnums = ccurnums;
	}	
}
