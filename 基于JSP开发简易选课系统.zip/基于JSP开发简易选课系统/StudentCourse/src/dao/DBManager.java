package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBManager {
	
	private static DBManager instance = new DBManager();
	//ʹ�õ���ģʽ
	public static DBManager getInstance(){
		return instance;
	}
	//ʹ��ͬ��������ֹ����û�ͬʱ�������ݿ�
	public synchronized  Connection getConnection(){
		String url = "jdbc:mysql://localhost:3306/eteaching?";
		Connection con = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(url, "root", "");
			System.out.println("---------------"+con);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally{
			return con;
			
		}
	
	}

}
