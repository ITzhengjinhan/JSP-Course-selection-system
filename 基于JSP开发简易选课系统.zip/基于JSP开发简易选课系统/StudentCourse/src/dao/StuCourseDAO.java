package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class StuCourseDAO {
	   //ѧ������ѧ�źͿγ̺Ž���ѡ��
	   public int selectCourse(String sno,int cno){
		   int result = -1;
		   Connection con  = DBManager.getInstance().getConnection();		
			  try {
					if (con != null) {		
						String sql = "insert into stu_course(sno,cno,sc_status,sc_score) values(?,?,?,?)";
						PreparedStatement pst = con.prepareStatement(sql); //ͨ��Connection��ȡStatement����
						pst.setString(1, sno);
						pst.setInt(2, cno);	
						pst.setInt(3,0);
						pst.setFloat(4,0.0f);
						if(pst.executeUpdate()>0){							 
							pst =  con.prepareStatement("update course set ccurnums=ccurnums+1 where cno=?");
							pst.setInt(1,cno);
						    result = pst.executeUpdate();						    	
						}		
												 			
					} else {
						System.out.println("connect DB failure!");
					}
				} catch (SQLException e) {			
					e.printStackTrace();
					 
				}finally{
				     return result;	
				}
	   }
	   
	  //�ж�ѧ���Ƿ��Ѿ�ѡ���˸ÿγ�
	  public boolean isSelectedCourse(String sno,int cno){
		  Connection con  = DBManager.getInstance().getConnection();		
		  try {
				if (con != null) {		
					String sql = "select * from stu_course where sno=? and cno=?";
					PreparedStatement pst = con.prepareStatement(sql); //ͨ��Connection��ȡStatement����
					pst.setString(1, sno);
					pst.setInt(2, cno);					
					ResultSet rs = pst.executeQuery();	//ͨ��Statement����ִ�в�ѯ
					while(rs.next()) {
						return true;
					}
					// �ر�����
					con.close();				
				} else {
					System.out.println("connect DB failure!");
				}
			} catch (SQLException e) {			
				e.printStackTrace();
				return false;
			}
			return false;	//���ز�ѯ���	
	  }
	  
	
}
