package servlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StuCourseDAO;

public class SelectCourseServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// ���ñ���
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		int cno = Integer.parseInt(request.getParameter("cno"));
		String sno = request.getParameter("sno");

		StuCourseDAO scd = new StuCourseDAO();
		if(scd.selectCourse(sno, cno)>0){
			out.println("<script>alert('ѡ�γɹ�!');window.location.href='student_mycourse.jsp';</script>");
		}else{
			out.println("<script>alert('ѡ��ʧ��!');window.location.href='student_selectcourse.jsp';</script>");
		}

	}

}
