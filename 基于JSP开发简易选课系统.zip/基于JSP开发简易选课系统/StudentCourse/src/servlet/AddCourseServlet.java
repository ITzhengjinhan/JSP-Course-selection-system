package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.CourseDAO;

import bean.CourseBean;

public class AddCourseServlet extends HttpServlet {

	/**
	 * The doPost method of the servlet. <br>
	 * 
	 * This method is called when a form has its tag value method equals to
	 * post.
	 * 
	 * @param request
	 *            the request send by the client to the server
	 * @param response
	 *            the response send by the server to the client
	 * @throws ServletException
	 *             if an error occurred
	 * @throws IOException
	 *             if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ���ñ���
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String cname = request.getParameter("cname");
		String ccredit = request.getParameter("ccredit");
		String cteacher = request.getParameter("cteacher");
		String cdepartment = request.getParameter("cdepartment");
		String cmaxnums = request.getParameter("cmaxnums");
		
		CourseBean cb = new CourseBean();
		cb.setCname(cname);
		cb.setCcredit(Float.parseFloat(ccredit));
		cb.setCteacher(cteacher);
		cb.setCdepartment(cdepartment);
		cb.setCmaxnums(Integer.parseInt(cmaxnums));
		
		CourseDAO cd = new CourseDAO();
		if(cd.addCourse(cb)>0){
			 out.println("<script>alert('�����γ̳ɹ�!');window.location.href='teacher_mycourse.jsp';</script>");
		}else{
			out.println("<script>alert('�����γ�ʧ��!');</script>");
			out.println("<a href='teacher_addcourse.jsp'>�������ӿγ�</a><br>");
			out.println("<a href='teacher_main.jsp'>���ؽ�ʦ��ҳ</a><br>");
		}
		
		
	}

}
