package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StudentDAO;
import dao.UserDAO;

import bean.StudentBean;

public class AdminStudentServlet extends HttpServlet {

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		// ���ñ���
		request.setCharacterEncoding("utf-8");
		response.setCharacterEncoding("utf-8");		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();	
		//��ʼִ������ɾ�����޸ģ�ͨ���ͻ����ύ��operate���������ж�
        StudentDAO stuDao = new StudentDAO();
        String method = request.getParameter("operate");
        if(method.equals("delete")){
        	//��ȡ�ύ�ı�������
    		String sno = request.getParameter("sno");    		
    		if(stuDao.deleteStu(sno)>0){
    			UserDAO userdao = new UserDAO();
    		    if(userdao.deleteUser(sno)>0){	 
    			 out.println("<script>alert('ɾ���ɹ�!');window.location.href='admin_student.jsp';</script>");
    		    }
    		}else{
    			 out.println("<script>alert('ɾ��ʧ��!');window.location.href='admin_student.jsp';</script>");
    		}    	
        }else{
        	//��ȡ�ύ�ı�������
    		String sno = request.getParameter("sno");
    		String sname = request.getParameter("sname");    		
    		String sdepartment = request.getParameter("sdepartment");
    		String sintro = request.getParameter("sintro");
            //ʵ����һ��StudentBean���洢�ύ�Ĳ���
    		StudentBean stu = new StudentBean();
    		stu.setSno(sno);
    		stu.setSname(sname);    	
    		stu.setSdepartment(sdepartment);
    		stu.setSintro(sintro);
    		if(method.equals("insert")){
    			//����ѧ���ɹ�����users������һ���û�
    			if(stuDao.insertStu(stu)>0){
    			 UserDAO userDao = new UserDAO();
    			 userDao.insertUser(sno, "123", "student");
       			 out.println("<script>alert('�����ɹ�!');window.location.href='admin_student.jsp';</script>");
       		    }else{
       			 out.println("<script>alert('����ʧ��!');window.location.href='admin_student.jsp';</script>");
       		   }
    		}else{
    			if(stuDao.updateStu(stu)>0){
          			 out.println("<script>alert('�޸ĳɹ�!');window.location.href='admin_student.jsp';</script>");
          		    }else{
          			 out.println("<script>alert('�޸�ʧ��!');window.location.href='admin_student.jsp';</script>");
          		   }
    		}
        	
        }

	}

}
